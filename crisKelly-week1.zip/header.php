	<div id="header">
		<ul id="header-nav">
			<li><a href="about.php">About Us</a></li>
			<li><a href="index.php">Home</a></li>
			<li><a href="contact.php">Contact Us</a></li>
		</ul>
	</div> <!-- end header -->
