	<div id="footer">
		<div id="footer-content">
				<h3><a href="http://scootrecords.bandcamp.com/" target="_blank">Scoot Records</a></h3>
				<p><a href="mailto:cris.kelly@gmail.com">cris.kelly@gmail.com</a></p>
				<h4>Copyright &copy 2012. Created by Cris Kelly. All rights reserved</h4>
		</div>
	</div> <!-- end footer -->
