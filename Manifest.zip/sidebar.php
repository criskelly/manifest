	<div id="page">
	<div id="sidebar">
		<div id="sidebar-top">
			<h3>What is The Manifest?</h3>
			<p>You are looking at the best way in the world to find musicians - by <strong>geographical location!</strong></p>
		</div>
		<div id="sidebar-mid">
			<h3>Why search The Manifest?</h3>
			<p><strong>Touring Musicians</strong> need local bands to co-bill with in order to bring an audience.</p>
			<p><strong>Wedding Planners</strong> are always on the hunt for great musicians.</p>
			<p><strong>Corporate Events</strong>, cruise ships, and music festivals constantly look for acts in their region.<p>
			<p><strong>The Manifest</strong> is the best way to connect.</p>
		</div>
		<div id="sidebar-button">
				<h3><a href="listed.php" target="_blank">GET LISTED</a></h3>
		</div>		
	</div> <!-- end sidebar -->